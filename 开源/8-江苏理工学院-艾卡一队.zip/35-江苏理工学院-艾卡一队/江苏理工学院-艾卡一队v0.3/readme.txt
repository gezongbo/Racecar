1、确认md码正确，解压gazebo_test_ws.zip压缩包。
2、进入工作空间下删除build和devel文件夹然后打开终端catkin_make编译。
3、进入start_game文件夹，在文件夹中打开终端键入python2 main.py
4、如果启动失败，确保source的路径正确，关掉终端再重新执行第三步。
