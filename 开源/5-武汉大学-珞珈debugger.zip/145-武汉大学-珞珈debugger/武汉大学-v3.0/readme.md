打开 gazebo_test_ws 工作空间
打开 start_game 包 ，在目录下运行 main.py 
按照终端提示进行
