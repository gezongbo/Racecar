本工作空间需要配置：
1、move_base
2、teb_local_planner
3、gmapping
4、amcl
5、ros-melodic-rqt-reconfigure
6、cartographer

