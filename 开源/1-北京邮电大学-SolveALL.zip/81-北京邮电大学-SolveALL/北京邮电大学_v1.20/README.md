# 部署手册

##### 1.解压并进入目录

```
unzip 北京邮电大学_v1.x.zip
cd ./北京邮电大学_v1.x/
```

##### 2.解压代码包到主目录中

##### 3.运行比赛启动脚本

```
cd ~/ifly_luke_ws/src/start_game/  && python2 main.py
```

##### 4.按照提示完成操作

